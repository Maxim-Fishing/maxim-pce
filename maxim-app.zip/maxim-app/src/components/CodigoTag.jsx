// Muestra un codigo Maxim resaltando sus partes:
// [LINEA 2][TIPO 3][MEDIDA 3][resto]  ej: SL ELV 100 X0001
export default function CodigoTag({ codigo }) {
  if (!codigo || codigo.length < 9) return <span className="cod">{codigo}</span>
  const linea  = codigo.slice(0, 2)
  const tipo   = codigo.slice(2, 5)
  const medida = codigo.slice(5, 8)
  const resto  = codigo.slice(8)
  return (
    <span className="cod" title={codigo}>
      <span className="cod__linea">{linea}</span>
      <span className="cod__tipo">{tipo}</span>
      <span className="cod__medida">{medida}</span>
      <span className="cod__resto">{resto}</span>
    </span>
  )
}
