import { useEffect, useState, useCallback } from 'react'
import { supabase } from '../supabaseClient'
import CodigoTag from '../components/CodigoTag'

const POR_PAGINA = 50

export default function Items({ perfil, usuario }) {
  const [items, setItems] = useState([])
  const [total, setTotal] = useState(0)
  const [q, setQ] = useState('')
  const [linea, setLinea] = useState('')
  const [estado, setEstado] = useState('')
  const [lineas, setLineas] = useState([])
  const [pagina, setPagina] = useState(0)
  const [cargando, setCargando] = useState(false)

  // Cargar el catalogo de lineas para el filtro
  useEffect(() => {
    supabase.from('lineas').select('codigo, nombre').order('codigo')
      .then(({ data }) => setLineas(data || []))
  }, [])

  const buscar = useCallback(async () => {
    setCargando(true)
    let query = supabase
      .from('items')
      .select(
        'id, codigo, descripcion, estado, linea_codigo, tipo_codigo, lineas(nombre), tipos_item(nombre)',
        { count: 'exact' }
      )
      .order('codigo')
      .range(pagina * POR_PAGINA, pagina * POR_PAGINA + POR_PAGINA - 1)

    const texto = q.trim()
    if (texto) query = query.or(`codigo.ilike.%${texto}%,sn.ilike.%${texto}%,descripcion.ilike.%${texto}%`)
    if (linea) query = query.eq('linea_codigo', linea)
    if (estado) query = query.eq('estado', estado)

    const { data, count, error } = await query
    if (!error) { setItems(data || []); setTotal(count || 0) }
    setCargando(false)
  }, [q, linea, estado, pagina])

  useEffect(() => { buscar() }, [buscar])
  // Al cambiar la busqueda o los filtros, volver a la primera pagina
  useEffect(() => { setPagina(0) }, [q, linea, estado])

  const paginas = Math.max(Math.ceil(total / POR_PAGINA), 1)

  return (
    <div className="app">
      <header className="barra">
        <div className="marca">
          <span className="marca__x">✕</span> MAXIM <span className="marca__sub">PCE</span>
        </div>
        <input
          className="buscar"
          placeholder="Buscar por código, S/N o descripción…"
          value={q}
          onChange={e => setQ(e.target.value)}
        />
        <div className="usuario">
          <span className="usuario__nombre">{perfil?.nombre || usuario.email}</span>
          <span className={`rol rol--${perfil?.rol || 'consulta'}`}>{perfil?.rol || 'consulta'}</span>
          <button className="salir" onClick={() => supabase.auth.signOut()}>Salir</button>
        </div>
      </header>

      <div className="filtros">
        <select value={linea} onChange={e => setLinea(e.target.value)}>
          <option value="">Todas las líneas</option>
          {lineas.map(l => (
            <option key={l.codigo} value={l.codigo}>
              {l.codigo}{l.nombre ? ' — ' + l.nombre : ''}
            </option>
          ))}
        </select>
        <select value={estado} onChange={e => setEstado(e.target.value)}>
          <option value="">Todos los estados</option>
          <option value="activo">Activo</option>
          <option value="en_mantenimiento">En mantenimiento</option>
          <option value="fuera_servicio">Fuera de servicio</option>
          <option value="inactivo">Inactivo</option>
        </select>
        <span className="conteo">{total.toLocaleString('es-CO')} ítems</span>
        {cargando && <span className="cargando">buscando…</span>}
      </div>

      <div className="tabla__wrap">
        <table className="tabla">
          <thead>
            <tr>
              <th>Código</th>
              <th>Descripción</th>
              <th>Línea</th>
              <th>Tipo</th>
              <th>Estado</th>
            </tr>
          </thead>
          <tbody>
            {items.map(it => (
              <tr key={it.id}>
                <td><CodigoTag codigo={it.codigo} /></td>
                <td className="desc">{it.descripcion}</td>
                <td>{it.lineas?.nombre || it.linea_codigo}</td>
                <td>{it.tipos_item?.nombre || it.tipo_codigo}</td>
                <td><span className={`badge badge--${it.estado}`}>{it.estado.replace('_', ' ')}</span></td>
              </tr>
            ))}
            {!cargando && items.length === 0 && (
              <tr><td colSpan="5" className="vacio">No hay ítems que coincidan. Ajusta la búsqueda o los filtros.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="paginacion">
        <button disabled={pagina === 0} onClick={() => setPagina(p => p - 1)}>Anterior</button>
        <span>Página {pagina + 1} de {paginas}</span>
        <button disabled={pagina + 1 >= paginas} onClick={() => setPagina(p => p + 1)}>Siguiente</button>
      </div>
    </div>
  )
}
