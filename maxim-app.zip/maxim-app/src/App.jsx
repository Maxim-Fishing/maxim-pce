import { useSession } from './lib/useSession'
import Login from './pages/Login'
import Items from './pages/Items'

export default function App() {
  const { session, perfil, cargando } = useSession()

  if (cargando) return <div className="centro">Cargando…</div>
  if (!session) return <Login />
  return <Items perfil={perfil} usuario={session.user} />
}
