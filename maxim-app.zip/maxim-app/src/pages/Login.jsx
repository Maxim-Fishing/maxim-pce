import { useState } from 'react'
import { supabase } from '../supabaseClient'

export default function Login() {
  const [correo, setCorreo] = useState('')
  const [clave, setClave] = useState('')
  const [error, setError] = useState('')
  const [cargando, setCargando] = useState(false)

  async function entrar(e) {
    e.preventDefault()
    setError('')
    setCargando(true)
    const { error } = await supabase.auth.signInWithPassword({ email: correo, password: clave })
    if (error) setError('No pudimos iniciar sesión. Revisa el correo y la contraseña.')
    setCargando(false)
  }

  return (
    <div className="login">
      <div className="login__panel">
        <div className="marca">
          <span className="marca__x">✕</span> MAXIM <span className="marca__sub">PCE</span>
        </div>
        <p className="login__lema">Control de herramientas y equipos de presión</p>
        <form onSubmit={entrar}>
          <label>
            Correo
            <input type="email" value={correo} onChange={e => setCorreo(e.target.value)} required autoComplete="username" />
          </label>
          <label>
            Contraseña
            <input type="password" value={clave} onChange={e => setClave(e.target.value)} required autoComplete="current-password" />
          </label>
          {error && <p className="error">{error}</p>}
          <button className="btn" disabled={cargando}>{cargando ? 'Entrando…' : 'Entrar'}</button>
        </form>
      </div>
    </div>
  )
}
